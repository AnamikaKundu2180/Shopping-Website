import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Routing from "./Routing";
import Home from "../pages/Home";

const Main = () => {
    return (
      <>
          
          <Header/>
          <Home/>
          <Footer/>
      </>
    )
  }
  
  export default Main