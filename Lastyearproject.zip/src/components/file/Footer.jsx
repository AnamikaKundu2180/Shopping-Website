import React from "react";
import brandlogo from "../Images/brandlogo.png"
import "../css/Footer.css"

function Footer() {
  return <>
    <div className="footer">
      <div className="footer-logo">
        <img src={brandlogo} alt=" " height="200px" width="200px"></img>
      </div> 
        <h4>Road no.7 Pennar Road, Sakchi, Jamshedpur, Jharkhand,  India </h4>
        <h4>+91 885-340-9623</h4>
        <h4><i class="fas fa-envelope"></i> ShopKart2024@gmail.com</h4>
        <i class="fab fa-facebook"></i>&nbsp;
        <i class="fab fa-instagram"></i>&nbsp;
        <i class="fab fa-twitter"></i>&nbsp;
        <i class="fab fa-whatsapp"></i>&nbsp;
        <i class="fab fa-linkedin"></i>&nbsp;
        <i class="fab fa-youtube"></i>&nbsp;
        <i class="fab fa-telegram"></i>
        <p>Copyright @ 2023 - All Right Reserved</p>
    </div>
  </>
}

export default Footer;
