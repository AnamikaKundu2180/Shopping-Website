import React from 'react'

function Routing() {
  return (
    <div>Routing</div>
  )
}

export default Routing