import React from 'react'
import img from "../Images/back.png"
import "../css/Home.css"
import image1 from "../Images/pic1.jpeg"
import image9 from "../Images/pic9.jpeg"
import image6 from "../Images/pic6.jpeg"
import image4 from "../Images/pic4.jpeg"
import image13 from "../Images/pic13.jpeg"
import image14 from "../Images/pic14.jpeg"
import image15 from "../Images/pic15.jpeg"
import image20 from "../Images/pic20.jpeg"
import image25 from "../Images/pic25.jpg"
import image27 from "../Images/pic27.jpg"
import image28 from "../Images/pic28.jpg"
import image32 from "../Images/pic32.jpg"
import image34 from "../Images/pic34.jpg"
import image35 from "../Images/pic35.jpg"
import image36 from "../Images/pic36.jpg"
import image39 from "../Images/pic39.jpg"
import dress1 from "../Images/dresss1.jpeg"
import dress2 from "../Images/dress2.jpg"
import back2 from "../Images/back2.png"
import pic44 from "../Images/pic44.jpg"
import pic43 from "../Images/pic43.jpg"
import pic51 from "../Images/pic51.jpg"
import pic52 from "../Images/pic52.jpg"
import pic53 from "../Images/pic53.jpg"
import pic54 from "../Images/pic54.jpg"
import pic77 from "../Images/pic77.webp"
import pic78 from "../Images/pic78.jpg"
import pic8 from "../Images/pic8.jpeg"
import pic42 from "../Images/pic42.jpg"
import pic22 from "../Images/pic22.jpeg"
import pic46 from "../Images/pic46.jpg"
import dress3 from "../Images/dress3.jpg"
import dress4 from "../Images/dress4.jpeg"
import dress5 from "../Images/dress5.jpg"
import pic80 from "../Images/pic80.webp"
import pic81 from "../Images/pic81.jpg"
import pic82 from "../Images/pic82.webp"
import pic83 from "../Images/pic83.jpg"
import pic84 from "../Images/pic84.jpg"
import pic85 from "../Images/pic85.jpg"
import pic86 from "../Images/pic86.jpeg"
import pic87 from "../Images/pic87.jpeg"
import pic88 from "../Images/pic88.jpeg"
import pic89 from "../Images/pic89.webp"
import pic90 from "../Images/pic90.jpg"
import pic91 from "../Images/pic91.jpg"
import { FaStar } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";
import { FaArrowRotateLeft } from "react-icons/fa6";
import { FaTruck } from "react-icons/fa";
import { FaThumbsUp } from "react-icons/fa";
import { FaTshirt } from "react-icons/fa";

function Home() {
  return (
    <>
      <section className="home">
        <div className="content">
            <h1><span>Clothing items</span>
              <br></br>
              As Per <span id="span2">Your Choice</span> <FaTshirt />
            </h1>
            <p>Fashion is about dressing according to what’s fashionable. 
                <br></br> Style is more about being yourself.</p>
            <div className="btn"><button>Shop Now</button></div>
        </div>
        <div className="img">
            <img src={img} alt=""></img>
        </div>
      </section>

      <br></br>

      <div className="container" id="product-cards">
        <h1 className="text-center">PRODUCTS</h1>
        <div className="row"  style={{marginTop:"30px"}}>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image1} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Bodycon Onepiece </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1000  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image9} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pink Shimmary Onepiece </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image6} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> RedVelvet Onepiece </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1400  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image4} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Oversized Pullover </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image13} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Purple Formal Shirt </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.800  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image14} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Blue Formal Shirt </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.800  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image15} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Blue TrackPant </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.800  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image20} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> OffBlack Jeans </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1600  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
        </div>
        <div className="row"  style={{marginTop:"30px"}}>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image25} alt=""></img>
                    <div className="card-body">
                        <h3 className="text-center"> Red Barbie Frock </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image27} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Multicolor Onepiece </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image28} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Twopiece Dress </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.650  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image32} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Short Dungree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image34} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> T-Shirt Pant and Hat </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image35} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pant and half Buffer Jacket </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image36} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Baby Jumpsuit </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={image39} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Kurta and Serwani </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1400  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="container" id="other-cards">
        <div className="row">
            <div className="col-md-6 py-3 py-md-0">
                <div className="card">
                    <img src={dress1} alt="" height="600px"></img>
                    <div className="card-img-overlay">
                        <h3>Bodycon Maxi</h3>
                        <h3>Dress</h3>
                        <h5>Latest Collection</h5>
                        <p>Up to 70% off</p>
                        <button id="shopnow">Shop Now</button>
                    </div>
                </div>
            </div>
            <div className="col-md-6 py-3 py-md-0" >
                <div className="card" >
                    <img src={dress2} alt="" height="600px"></img>
                    <div className="card-img-overlay" >
                        <h3>Blue Blazer</h3>
                        <h5>Latest Collection</h5>
                        <p>Up to 70% off</p>
                        <button id="shopnow">Shop Now</button>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <section className="banner">
        <div className="content">
            <h1><span>Summer Holiday</span>
              <br></br>
              Sale Up to <span id="span2">70%</span> off
            </h1>
            <p>Fashion is about dressing according to what’s fashionable. 
                <br></br>Style is more about being yourself.</p>
            <div className="btn"><button>Shop Now</button></div>
        </div>
        <div className="img">
            <img src={back2} alt=""></img>
        </div>
      </section>

      <div className="container" id="product-cards">
        <div className="row"  style={{marginTop:"30px"}}>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic44} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pencil Heel </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1300  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic43} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Black leather Boots </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic51} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Winter wear Boots </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1400  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic52} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Brown Velvet Boots </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic53} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pink Leather HandBag </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1800  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic54} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Darkpink HandBag </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1200  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic77} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pure Leather Office Bag </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic78} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> MultiPurpuse Office Bag  </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2000  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic8} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Velvet Winterwear Jacket </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1200  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic42} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Parasute Jacket </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic22} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Black Leather Jacket </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic46} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Turtle Neck Pullover </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1000  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      
      <div className="container" id="other">
        <div className="row">
            <div className="col-md-4 py-3 py-md-0">
                <div className="card">
                    <img src={dress3} alt=" " height="600px"></img>
                    <div className="card-img-overlay">
                        <h3>Banarasi Saree</h3>
                        <h5>Latest Collection</h5>
                        <p>Up to 60% off</p>
                        <button id="shopnow">Shop Now</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 py-3 py-md-0" >
                <div className="card" >
                    <img src={dress4} alt="" height="600px"></img>
                    <div className="card-img-overlay" >
                        <h3>Bollywood Saree</h3>
                        <h5>Latest Collection</h5>
                        <p>Up to 60% off</p>
                        <button id="shopnow">Shop Now</button>
                    </div>
                </div>
            </div>
            <div className="col-md-4 py-3 py-md-0" >
                <div className="card" >
                    <img src={dress5} alt="" height="600px"></img>
                    <div className="card-img-overlay" >
                        <h3>Kanjivaram Saree</h3>
                        <h5>Latest Collection</h5>
                        <p>Up to 60% off</p>
                        <button id="shopnow">Shop Now</button>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="container" id="product-cards">
        <div className="row"  style={{marginTop:"30px"}}>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic87} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Black and Red Banarasi saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2600  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic88} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Red and White Banarasi Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic86} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Purple dotted print Banarasi Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2200  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic89} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Banarasi Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.1700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic83} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Purple Stone Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2700  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic84} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Golden Silk Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic85} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Golden Black Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic90} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Pink Shimmary Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.3200  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic80} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Kanjivaram green silk Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic81} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Cream color pure soft lichi silk saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.3500  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic82} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Bahuji Grey Banarasi Butta silk Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.2900  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
            <div className="col-md-3" py-md-0>
                <div className="card">
                    <img src={pic91} alt="" height="447px"></img>
                    <div className="card-body">
                        <h3 className="text-center"> Womens Kanchipuram Wedding Saree </h3>
                        <div className="star text-center">
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                            <FaStar/>
                        </div>
                        <h2>Rs.3200  </h2> 
                        <div className="btn"><button>Add to Cart</button> <button>Buy Now</button></div>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="container" id="offer">
        <div className="row">
            <div className="col-md-3 py-3 py-md-0" id='i'>
                <FaShoppingCart />
                <h3>Free Shipping</h3>
                <p>On Order above Rs.1000</p>
            </div>
            <div className="col-md-3 py-3 py-md-0" id='i'>
                <FaArrowRotateLeft />
                <h3>Free Return</h3>
                <p>Within 30 days</p>
            </div>
            <div className="col-md-3 py-3 py-md-0" id='i'>
                <FaTruck />
                <h3>Fast Delivery</h3>
                <p>World Wide</p>
            </div>
            <div className="col-md-3 py-3 py-md-0" id='i'>
                <FaThumbsUp />
                <h3>Big choice</h3>
                <p>Of product</p>
            </div>
        </div>
      </div>

      <div className="container" id="newslater">
        <h3 className="text-center">Subscribe To The Clothing Shop For Latest Upload</h3>
        <div className="input text-center">
            <input type="text" placeholder="Enter Your Email.."></input>
            <button id="subscribe">SUBSCRIBE</button>
        </div>
      </div>
    </>
  )
}

export default Home