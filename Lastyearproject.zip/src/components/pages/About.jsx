import React from 'react'

function About() {
  return (
    <>
      <div class="container" id="about">
        <h3>PRODUCT</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit laudantium doloremque ratione fuga voluptatibus, sequi totam necessitatibus dolor quis officiis architecto, commodi sunt quidem eum alias voluptas esse. Eius sequi expedita possimus. Tenetur a dicta quibusdam recusandae blanditiis! Quos impedit alias adipisci inventore repellat ullam recusandae hic, eligendi minus enim unde autem laboriosam at, doloribus maxime corrupti explicabo, expedita illo atque! Explicabo earum aut modi nobis molestias nesciunt excepturi perferendis necessitatibus sequi, pariatur, iure nisi dolor nulla deleniti? Facilis quaerat, esse provident ipsum corrupti voluptatem aspernatur eveniet modi accusantium perferendis optio ex excepturi aliquid velit nam explicabo harum ducimus nemo.</p>
          
        <div class="row" style="margin-top: 50px;">
            <div class="col-md-5 py-md-0">
             <div class ="card">
                <img src="./Images/back.png" alt=""></img>
             </div>
            </div>
            <div class="col-md-7 py-3 py-md-0">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas fuga animi, nemo consectetur nihil aperiam qui. Vel impedit sapiente perspiciatis ex, blanditiis odio perferendis explicabo culpa a, vero quis asperiores.</p>
                   <button>Read more...</button>
            </div>
        </div>
      </div>
    </>
  )
}

export default About